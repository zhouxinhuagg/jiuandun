package com.example.docker_register_cloud

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
